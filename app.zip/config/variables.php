<?php
  // Variables
  return [
    "creatorName" => "Usman Muktar",
    "creatorUrl" => "https://mukeey.online",
    "templateName" => "Smart Farm",
    "templateDescription" => "Most Powerful & Comprehensive Bootstrap 5 HTML Admin Dashboard Template built for developers!",
    "templateKeyword" => "dashboard, bootstrap 5 dashboard, bootstrap 5 design, bootstrap 5, bootstrap 5 free, free admin template",
    "licenseUrl" => "https://mukeey.online/license/",
    "repository" => "https://github.com/mualiyu/hydro-phonix",
    "facebookUrl" => "https://www.facebook.com/",
    "twitterUrl" => "https://twitter.com/",
    "githubUrl" => "https://github.com/",
    "dribbbleUrl" => "https://dribbble.com/",
    "instagramUrl" => "https://www.instagram.com/"
  ];
