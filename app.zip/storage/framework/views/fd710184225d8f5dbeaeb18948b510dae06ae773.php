<?php $__env->startSection('title', 'Actuators - list'); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/ui-modals.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold py-3 mb-4">
  <span class="text-muted fw-light">Actuator /</span> List
  <button style="float: right;" class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#modalCenter">Add New</button>
</h4>

<!-- Basic Bootstrap Table -->
<div class="card" >
  <h5 class="card-header">Actuators</h5>
  <div class="table-responsive text-nowrap">
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>DeviceId</th>
          <th>No. of Nodes</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0">
          <?php if(count($actuators)>0): ?>
            <?php $__currentLoopData = $actuators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <tr>
              <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($a->name); ?></strong></td>
              <td><?php echo e($a->device_id ?? "Not connected"); ?></td>
              <td>
                <?php echo e(count($a->nodes)); ?>

              </td>
              <td>
                  <?php if($a->value == 1): ?>
                    <span class="badge bg-label-primary me-1">Active</span></td>
                  <?php else: ?>
                    <span class="badge bg-label-warning me-1">Inactive</span>
                  <?php endif; ?>
              <td>
                <div class="dropdown">
                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                  <div class="dropdown-menu" style="position: relative; z-index:99999999;">
                    <a class="dropdown-item" href="<?php echo e(route('actuator', ['actuator'=>$a->id])); ?>"><i class="bx bx-edit-alt me-1"></i> View</a>
                    <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                    <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                  </div>
                </div>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
              <td colspan="5" align="center">No Actuators found! <a href="#" data-bs-toggle="modal" data-bs-target="#modalCenter">Add One</a></td>
          </tr>
          <?php endif; ?>
        
      </tbody>
    </table>
  </div>
</div>
<!--/ Basic Bootstrap Table -->
<!-- Vertically Centered Modal -->

    <!-- Modal -->
    <div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <form action="<?php echo e(route('store_actuator')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="modalCenterTitle">Create Actuator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="row g-2">
                    <div class="col mb-0">
                      <label for="nameWithTitle" class="form-label">Name</label>
                      <input type="text" id="nameWithTitle" name="name" class="form-control" placeholder="Enter Name">
                    </div>
                  <div class="col mb-0">
                    <label for="emailWithTitle"  class="form-label">Device Id <small>(optional)</small></label>
                    <input type="text" id="emailWithTitle" name="device_id" class="form-control" placeholder="The No. on the Device">
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
            </div>
        </form>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mukeey/projects/smart-farm-mukeey/farm-system/resources/views/main/actuator/index.blade.php ENDPATH**/ ?>