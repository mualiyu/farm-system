<?php $__env->startSection('title', 'Actuator - Details & Nodes'); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/pages-account-settings-account.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold py-3 mb-4">
  <span class="text-muted fw-light">Actuator /</span> <?php echo e($actuator->name); ?> / Info
</h4>

<div class="row">
  <div class="col-md-12">
    <div class="card mb-4">
      <h5 class="card-header"><?php echo e($actuator->name); ?> Details</h5>
      <!-- Account -->
      <div class="card-body">
        <div class="d-flex align-items-start align-items-sm-center gap-5">
          
          <div class="button-wrapper ml-5">
            <p class="text mb-0">This actuator covers <?php echo e(count($nodes)); ?> nodes and it's <span class="badge bg-label-primary me-1">Active</span></p>
            <p class="text mb-0">Device ID : <?php echo e($actuator->device_id); ?></p>
            <br>
            <button type="button" class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#modalCenter">
              <i class="bx bx-reset d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Add node</span>
            </button>
            <button type="button" class="btn btn-outline-secondary account-image-reset" data-bs-toggle="modal" data-bs-target="#modalReset">
              <i class="bx bx-reset d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Reset</span>
            </button>
            <mode-vue device_id="<?php echo e($actuator->device_id); ?>" mode="<?php echo e($s_status->mode); ?>" pump="<?php echo e($s_status->pump); ?>" />
            </div>
          </div>
          <div class="button-wrapper ">
            <pump-vue device_id="<?php echo e($actuator->device_id); ?>" mode="<?php echo e($s_status->mode); ?>" pump="<?php echo e($s_status->pump); ?>" />
          </div>
      </div>
      <hr class="my-0">
      
      <h6 class="card-header">Nodes List</h6>
      <div class="table-responsive text-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>Node No.</th>
          <th>Name</th>
          <th>status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0">
          <?php if(count($nodes)>0): ?>
            <?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <tr>
              <td><?php echo e($n->num ?? "Not connected"); ?></td>
              <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($n->name); ?></strong></td>
              <td>
                  <span class="badge bg-label-primary me-1">Connected (Live)</span></td>
              <td>
                <div class="dropdown">
                  <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                  <div class="dropdown-menu" style="position: relative; z-index:99999999;">
                    <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i> View live</a>
                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modalupdatenode<?php echo e($n->id); ?>"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                    <a class="dropdown-item" href="<?php echo e(route('delete_node', ['node'=>$n->id])); ?>" onclick="event.preventDefault(); 
                    if(confirm('Are you sure you want to delete this node (<?php echo e($n->name); ?>)\nEither OK or Cancel.')){document.getElementById('logout-form<?php echo e($n->id); ?>').submit();}"><i class="bx bx-trash me-1"></i> Delete</a>
                    <form id="logout-form<?php echo e($n->id); ?>" action="<?php echo e(route('delete_node', ['node'=>$n->id])); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                  </div>
                </div>
              </td>
            </tr>
            
    <div class="modal fade" id="modalupdatenode<?php echo e($n->id); ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <form id="updateformnode<?php echo e($n->id); ?>" action="<?php echo e(route('update_node', ['node'=>$n->id])); ?>" method="post">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modalCenterTitle">Update Node</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                    <?php echo csrf_field(); ?>
                    <div class="col-12">
                        <label for="nameWithTitle" class="form-label">Name</label>
                        <input type="text" id="nameWithTitle" value="<?php echo e($n->name); ?>" required name="name" class="form-control" placeholder="Enter Name">
                    </div>
                    <div class="col-12">
                        <label for="nameWithTitle" class="form-label">Node Number</label>
                  <input type="text" id="nameWithTitle" name="num" required value="<?php echo e($n->num); ?>" class="form-control" placeholder="Enter the number on the node device">
                    </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" onclick="event.preventDefault(); document.getElementById('updateformnode<?php echo e($n->id); ?>').submit();" class="btn btn-primary">Update</button>
                
              </div>
            </div>
        </form>
      </div>
    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
              <td colspan="5" align="center">No nodes found! <a href="#" data-bs-toggle="modal" data-bs-target="#modalCenter">Add One</a></td>
          </tr>
          <?php endif; ?>
      </tbody>
    </table>
  </div>
    </div>
    
  </div>
</div>

<!-- Modal -->
    <div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('store_node', ['actuator'=>$actuator->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="modalCenterTitle">Create Node</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <label for="nameWithTitle" class="form-label">Name</label>
                  <input type="text" id="nameWithTitle" name="name" class="form-control" placeholder="Enter Name">
                  <br>
                  <label for="nameWithTitle" class="form-label">Node Number</label>
                  <input type="text" id="nameWithTitle" name="num" class="form-control" placeholder="Enter the number on the node device">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
            </div>
        </form>
      </div>
    </div>

    
    <div class="modal fade" id="modalReset" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('reset_actuator', ['actuator'=>$actuator->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="modalCenterTitle">Reset Actuator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <div class="row">
                      <div class="col-12">
                        <label for="idWithTitle" class="form-label">Device Id</label>
                        <input type="text" id="idWithTitle" name="device_id" class="form-control" placeholder="Enter device Id">
                    </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Reset</button>
              </div>
            </div>
        </form>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mukeey/projects/smart-farm-mukeey/farm-system/resources/views/main/actuator/info.blade.php ENDPATH**/ ?>