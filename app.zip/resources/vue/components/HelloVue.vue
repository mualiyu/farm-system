// resources/components/HelloVue.vue

<template>
  <p></p>
</template>

<script>
export default {
    name: 'HelloVue'
}
</script>